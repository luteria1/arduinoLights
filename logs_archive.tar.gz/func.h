#pragma once
#include"share.h"

int logScaleBins(int,int,int*);

int printOut(double*,int);

int init_dataStructures(struct audio_data*,struct main_data*);
