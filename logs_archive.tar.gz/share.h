#pragma once
#include<pthread.h>
#include<fftw3.h>
#define BUFFER_SIZE 512;
struct audio_data {
	double *arctic;
	int arctic_buffer_size;
	int input_buffer_size;
	unsigned int rate,channels;
	int format;
	char *source;
	int terminate;
	int samplesCounter;
	pthread_mutex_t lock;
};

struct main_data {
	double *inputBuffer;
	int input_buffer_size;

	int fft_raw_input_size;
	double *in_l;
	double *in_r;

	fftw_complex *out_l;
	fftw_complex *out_r;

	fftw_plan plan_l;
	fftw_plan plan_r;

	double eq;
	double *multiplier;

};


