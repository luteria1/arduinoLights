#include"share.h"
#include<stdlib.h>
#include<stdio.h>
#include"pulse.h"
#include<ncurses.h>
#include<string.h>
#include"func.h"
#include<pthread.h>
#include<stdint.h>
#include<math.h> 
#include<unistd.h>
#include<wiringPiSPI.h>
#include<wiringPi.h>

#define BIN_NUM 8 
#define SPI_CHANNEL 0
#define SPI_CLOCK_SPEED 2000000
#define LEDCOUNT 240.0;


int main(){
	initscr();
	timeout(1);
	//init SPI
	unsigned char SPIbuffer[32];
	if (wiringPiSPISetupMode(SPI_CHANNEL,SPI_CLOCK_SPEED,0)==-1){
		endwin();
		return -1;
	};
	wiringPiSetup();
	pinMode(21,INPUT);
	

	//init data structures
	struct audio_data audio;
	memset(&audio,0,sizeof(audio));
	
	struct main_data mainData;
	memset(&mainData,0,sizeof(mainData));

	//load up the data structures
	init_dataStructures(&audio,&mainData);

	//init fast access ds
	int tick=0;
	int cutoffs[BIN_NUM];
	double display[BIN_NUM];
	double mem[BIN_NUM];
	double peaks[BIN_NUM];
	unsigned char finalOutput[BIN_NUM+1];
	
	//beat detection init.
	int BEAT_NUM =50;
	double beatArr[BIN_NUM][BEAT_NUM];
	for (int i=0;i<2;i++){
		for(int ii=0;ii<BEAT_NUM;ii++){
			beatArr[i][ii]=0.0;	
		}
	}
	double beatAvgs[BIN_NUM];
	int beatCounter=0;
	
	logScaleBins(mainData.fft_raw_input_size/2,BIN_NUM,cutoffs);
	for (int i=0;i<BIN_NUM;i++){
		display[i]=0.0;
		peaks[i]=0.0000001;
		finalOutput[i]=0;
		mem[i]=0.0;
	}

	//activate pulseAudio thread
	getPulseDefaultSink((void *)&audio);
	int thr_id;
	pthread_t p_thread;
	thr_id = pthread_create(&p_thread, NULL, input_pulse, (void *)&audio);
	
	while(getch()!='q'){/////START OF MAINLOOP
reset:
		clear();	
		// Get input form pulse ///////////////////////////////
		pthread_mutex_lock(&audio.lock);
		
		//stop overflow
		if (audio.samplesCounter>mainData.input_buffer_size){
			audio.samplesCounter = mainData.input_buffer_size;
		}
		
		//main data input block
		if (audio.samplesCounter>0){
			//shifting input buffer
			for (uint16_t n = mainData.input_buffer_size - 1;n>=audio.samplesCounter;n--){
				mainData.inputBuffer[n]=mainData.inputBuffer[n-audio.samplesCounter];
			}
			//Fill 'er up
			for (uint16_t n = 0; n < audio.samplesCounter; n++) {
            			mainData.inputBuffer[audio.samplesCounter- n - 1] = audio.arctic[n];
        		}
			
		}else{//retry if there is no audio inputs during call
			pthread_mutex_unlock(&audio.lock);
			usleep(100);		
			goto reset;
		}
		pthread_mutex_unlock(&audio.lock);
		///////////////////////////////////////////////////////
		
		//seperaate channels
		for (int i=0; i< mainData.fft_raw_input_size;i++){
			mainData.in_r[i]=mainData.inputBuffer[i*2];
			mainData.in_l[i]=mainData.inputBuffer[i*2+1];
		}

		// hann windows
		for (int i=0;i<mainData.fft_raw_input_size;i++){
			mainData.in_r[i]*=mainData.multiplier[i];
			mainData.in_l[i]*=mainData.multiplier[i];
		}

		//make do math hard
		fftw_execute(mainData.plan_l);
		fftw_execute(mainData.plan_r);
		

		//load up display
		int a=0;
		for (int i=0;i<BIN_NUM;i++){
			for (int ii=0;ii<cutoffs[i];ii++){
				display[i]+=hypot(mainData.out_l[a][1],mainData.out_r[a][0]);
				a++;
			}
			display[i]/=(double) cutoffs[i];
			display[i]*=mainData.eq;
		}
		
		//load up peaks
		for (int i=0;i<BIN_NUM;i++){
			if (peaks[i]<display[i]){
				peaks[i]=display[i];
			}
			display[i]=(display[i]/peaks[i])*LEDCOUNT;

			//load into memory
			if (mem[i]>display[i]){
				if (tick%15==0){
					display[i]=mem[i]-((mem[i]-display[i])/4.0);
				}else{
					display[i]=mem[i];
				}
			}
			
			mem[i]=display[i];
		}
		

		for(int i=0;i<BIN_NUM;i++){
			display[i]*=1.0-((double)i*0.00);
			finalOutput[i]=0;
		};

		double top=display[7];
		finalOutput[7]= (unsigned char) top;
		
		for (int i=BIN_NUM-2;i>-1;i--){
			if (display[i]>top){
				finalOutput[i]=(unsigned char) (display[i]-top);
				top=display[i];
			}
		
		}
		
	
		// sned to arduino if ready

		unsigned char buf;
		if (digitalRead(29)==1){
			for (int i=0;i<BIN_NUM;i++){
				buf=finalOutput[i];
				wiringPiSPIDataRW(SPI_CHANNEL,&buf,1);
				usleep(20);
			}
			buf=finalOutput[8];
			wiringPiSPIDataRW(SPI_CHANNEL,&buf,1);
			usleep(20);
		}			
		

		tick++;
		if (tick>1024){
			tick=0;
		}
	}///END OF MAINLOOP

	endwin();

	
}
