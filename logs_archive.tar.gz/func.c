#include <math.h>
#include <stdio.h>
#include <ncurses.h>
#include "share.h"
#include <string.h>
#include <stdlib.h>

int logScaleBins(int size, int binNum, int *cutoffs){
	int tmp[binNum];
	
	//create scale
	for (int i=0;i<binNum;i++){
		tmp[i] = pow((double) size,((double) (i+1)/binNum));
	}
	
	//How many values in each bin
	cutoffs[0]=tmp[0];
	for (int i=1;i<binNum;i++){
		cutoffs[i]=tmp[i]-tmp[i-1];
	}

	//shift scale across by shifter;
	int shift=15;
	cutoffs[binNum-1]-=shift*(binNum-1);
	for (int i=0;i<binNum-1;i++){
		cutoffs[i]+=shift;
	}
	


	return 1;
}

int printOut(double *display,int BIN_NUM){
	int x,y;
	getmaxyx(stdscr,y,x);
	for (int i =0;i<BIN_NUM;i++){
		for(int iii=0;iii<5;iii++){
		for (int ii=0;ii<(int) display[i];ii++){
			mvaddch(y-ii,i*5+iii,'0');
		}
		}
	}
	return 1;
}

int init_dataStructures(struct audio_data *audio, struct main_data *mainData){
	audio->rate=44100;
	audio->format=16;
	audio->channels=2;
	audio->terminate=0;
	audio->input_buffer_size = audio->channels* BUFFER_SIZE;
	audio->arctic_buffer_size = audio->input_buffer_size * 8;
	audio->arctic = (double*)malloc(audio->arctic_buffer_size*sizeof(double));
	memset(audio->arctic,0,sizeof(double)*audio->arctic_buffer_size);
	
	mainData->input_buffer_size=8192*audio->channels;
	mainData->inputBuffer=(double*)malloc(mainData->input_buffer_size*sizeof(double));
	
	mainData->fft_raw_input_size = 8192;	
	
	mainData->in_l=fftw_alloc_real(8192);
	memset(mainData->in_l,0,8192*sizeof(double));
	mainData->in_r=fftw_alloc_real(8192);
	memset(mainData->in_r,0,8192*sizeof(double));
	
	mainData->multiplier=(double*)malloc(mainData->fft_raw_input_size*sizeof(double));
	memset(mainData->multiplier,0,mainData->fft_raw_input_size);

	for(int i=0;i<mainData->fft_raw_input_size;i++){
		mainData->multiplier[i]=0.5 * (1-cos(2*M_PI*i/(mainData->fft_raw_input_size-1)));
	}
	mainData->out_r=fftw_alloc_complex(mainData->fft_raw_input_size/2+1);
	memset(mainData->out_r,0,sizeof(fftw_complex)*(mainData->fft_raw_input_size/2+1));
	mainData->out_l=fftw_alloc_complex(mainData->fft_raw_input_size/2+1);
	memset(mainData->out_r,0,sizeof(fftw_complex)*(mainData->fft_raw_input_size/2+1));

	mainData->plan_l=fftw_plan_dft_r2c_1d(mainData->fft_raw_input_size,mainData->in_l,mainData->out_l,FFTW_MEASURE);
	mainData->plan_r=fftw_plan_dft_r2c_1d(mainData->fft_raw_input_size,mainData->in_r,mainData->out_r,FFTW_MEASURE);

	mainData->eq= 1.0/pow(2,29)/log2(mainData->fft_raw_input_size);
	return 1;
}



