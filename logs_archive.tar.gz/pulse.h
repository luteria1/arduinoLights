// header file for pulse, part of cava.

#pragma once

void *input_pulse(void *data);
void getPulseDefaultSink();

